#!/usr/bin/env python3
"""
CIFAR-10 流式联邦学习 - 与 MNIST 版本参数完全一致

四种 Policy:
1. optimal: K=11 Optimal
2. dpp: K=4 DPP, Pdim=100
3. oracle: K=1 Oracle
4. hybrid: 5 Dynamic + 5 Static

Usage:
    python run_streaming_cifar.py --policy optimal
    python run_streaming_cifar.py --policy dpp
    python run_streaming_cifar.py --policy oracle
    python run_streaming_cifar.py --policy hybrid
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
import torchvision
import torchvision.transforms as transforms
import numpy as np
import copy
import time

# 启用 TF32 加速 (A100)
torch.set_float32_matmul_precision('medium')

# 禁用 CUDAGraph 动态形状警告
import torch._inductor.config as config
config.triton.cudagraph_skip_dynamic_graphs = True
import os
import json
import argparse
from collections import deque

# Global configuration (can be modified)
BUFFER_SIZES = [16, 18, 20, 22, 24, 16, 18, 20, 22, 24]  # 10 clients, heterogeneous buffer sizes
COST_BUDGET = 110.0  # cost budget 110

# 设置保存路径（自动检测 Colab 环境）
if os.path.exists('/content'):
    # Colab 环境
    SAVE_DIR = "/content/MobiHoc26_CIFAR"
else:
    # 本地环境
    SAVE_DIR = "/Users/zzy/Desktop/MobiHoc26_CIFAR"

DATA_DIR = os.path.join(SAVE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)


# ==================== K-Step Memory 组件 (与 MNIST 一致) ====================

class KStepMemory:
    """K-Step buffer: 保留最近 K 轮接纳的样本"""
    def __init__(self, K=5):
        self.K = int(K)
        self.buf = deque()  # each entry: (sample_idx, admit_round)

    def set_K(self, K):
        """动态更新 K 值 (用于 DPP)"""
        self.K = int(K)

    def drop_first(self, current_round):
        """淘汰超过 K 轮的样本"""
        while self.buf and (current_round - self.buf[0][1]) >= self.K:
            self.buf.popleft()

    def admit(self, indices, current_round):
        """接纳新样本"""
        for idx in indices:
            self.buf.append((int(idx), int(current_round)))

    def indices(self):
        """返回当前 buffer 中的所有样本索引"""
        return [idx for idx, _ in self.buf]

    def __len__(self):
        return len(self.buf)


class StaticMemory:
    """Static buffer: 固定大小，不淘汰，不接纳新样本 (MNIST hybrid 使用)"""
    def __init__(self, fixed_indices):
        self.fixed_indices = list(fixed_indices)

    def drop_first(self, current_round):
        """Static memory 不淘汰"""
        pass

    def admit(self, indices, current_round):
        """Static memory 不接纳新样本"""
        pass

    def indices(self):
        return self.fixed_indices

    def __len__(self):
        return len(self.fixed_indices)


class OracleSampler:
    """无放回采样器，样本用尽后自动 reset"""
    def __init__(self, all_indices, seed=42):
        self.rng = np.random.default_rng(seed)
        self.base = np.array(list(all_indices), dtype=int)
        self.reset()

    def reset(self):
        """重置采样池"""
        self.available = self.rng.permutation(self.base).tolist()
        self.admitted = set()
        self.reset_count = 0

    def sample_fresh(self, n):
        """采样 n 个新样本"""
        n = int(n)
        if n <= 0:
            return []

        remaining = [idx for idx in self.available if idx not in self.admitted]

        if len(remaining) < n:
            self.reset()
            remaining = self.available.copy()

        if len(remaining) < n:
            n = len(remaining)

        if n == 0:
            return []

        out = remaining[:n]
        self.admitted.update(out)
        return out


class RateDither:
    """Rate dither: 按概率 lambda 决定接纳数量"""
    def __init__(self, lam=5.0):
        self.lam = float(lam)
        self.res = 0.0

    def set_lambda(self, lam):
        """动态调整 lambda（用于 DPP）"""
        self.lam = float(lam)

    def next_int(self):
        """返回本次接纳的样本数"""
        self.res += self.lam
        k = int(np.floor(self.res + 1e-12))
        self.res -= k
        return k


class DynamicRateDither:
    """动态 lambda 的 rate dither"""
    def __init__(self):
        self.res = 0.0
        self.current_lam = 0.0

    def set_lambda(self, lam):
        self.current_lam = float(lam)

    def next_int(self):
        self.res += self.current_lam
        k = int(np.floor(self.res + 1e-12))
        self.res -= k
        return k


# ==================== DPP Policy (与 MNIST 一致，Pdim=100) ====================

class DPPLambdaPolicy:
    """
    DPP Policy for Dynamic Lambda Admission Control.
    完整的 MNIST 版本实现。
    """

    def __init__(self, cost_budget, buffer_sizes, K_initial=4, K_target=11, K_growth_interval=500, V=10000.0, D=1000.0,
                 sigma=10.0, eta_tilde=0.01, C1=1000.0, C2=1.0, Pdim=1024,
                 optimal_lambda_sum=70.0, rho=0.9999999):
        self.cost_budget = cost_budget
        self.buffer_sizes = np.array(buffer_sizes)
        self.K_initial = K_initial
        self.K_target = K_target
        self.K_growth_interval = K_growth_interval
        self.V = V
        self.num_clients = len(buffer_sizes)
        self.sum_B_m = sum(buffer_sizes)

        self.D = D
        self.sigma = sigma
        self.eta_tilde = eta_tilde
        self.C1 = C1
        self.C2 = C2
        self.Pdim = Pdim

        # Dynamic lambda range parameters
        self.optimal_lambda_sum = optimal_lambda_sum  # Target: sum of optimal lambda_m
        self.rho = rho  # Decay rate

        self.Z = 0.0
        self.n_t = 0
        self.N_t = Pdim
        self.lambda_history = []

        # Current K (will grow over time)
        self.current_K = K_initial
        self.prev_K = K_initial  # Track previous K for proper dropping calculation
        self.memories = None  # Will be set by setup_dpp_policy

    def set_memories(self, memories):
        """Store reference to memories for dynamic K updates"""
        self.memories = memories

    def get_current_K(self, round_num):
        """Get current K value, grows from K_initial to K_target"""
        # K grows by 1 every K_growth_interval rounds
        growth = (round_num - 1) // self.K_growth_interval
        K = self.K_initial + growth
        return min(K, self.K_target)

    def update_memories_K(self, round_num):
        """Update K for all memories"""
        current_K = self.get_current_K(round_num)
        if self.memories:
            for memory in self.memories.values():
                if hasattr(memory, 'set_K'):
                    memory.set_K(current_K)

    def compute_penalty(self, n_t, N_t):
        """Compute per-round penalty p(t)"""
        n_t = max(n_t, 1)
        N_t = max(N_t, 1)

        term1 = self.D * self.sigma * (1.0 / np.sqrt(n_t) - 1.0 / np.sqrt(N_t))
        term2 = self.eta_tilde * (self.sigma ** 2) * (1.0 / n_t - 1.0 / N_t)
        log_term = 1.0 + np.log(np.sqrt(N_t / self.Pdim))
        term3 = 10.0 * self.C1 * np.sqrt(self.Pdim / N_t) * log_term

        return term1 + term2 + term3

    def compute_dpp_objective(self, Lambda, c_t, n_t, N_t):
        """Compute DPP objective"""
        C_t = c_t * Lambda
        p_t = self.compute_penalty(n_t, N_t)
        J_t = self.Z * (C_t - self.cost_budget) + self.V * p_t
        return J_t

    def find_optimal_lambda(self, c_t, Lambda_min=1.0, Lambda_max=1000.0, K=None, tolerance=0.1):
        """Find optimal Lambda using ternary search"""
        if K is None:
            K = self.current_K

        # Use prev_K for dropping calculation to avoid using stale high-lambda history
        # when K has just increased
        effective_K = min(K, self.prev_K)
        if len(self.lambda_history) >= effective_K:
            Lambda_dropping = self.lambda_history[-effective_K]
        else:
            Lambda_dropping = 0

        n_prev = self.n_t
        N_prev = self.N_t

        left, right = Lambda_min, Lambda_max
        best_Lambda = (left + right) / 2
        best_J = float('inf')

        while right - left > tolerance:
            m1 = left + (right - left) / 3
            m2 = right - (right - left) / 3

            n_t1 = n_prev - Lambda_dropping + m1
            N_t1 = N_prev + m1
            J1 = self.compute_dpp_objective(m1, c_t, n_t1, N_t1)

            n_t2 = n_prev - Lambda_dropping + m2
            N_t2 = N_prev + m2
            J2 = self.compute_dpp_objective(m2, c_t, n_t2, N_t2)

            if J1 < best_J:
                best_J = J1
                best_Lambda = m1
            if J2 < best_J:
                best_J = J2
                best_Lambda = m2

            if J1 < J2:
                right = m2
            else:
                left = m1

        return best_Lambda

    def get_lambda_for_round(self, round_num, round_cost):
        """Get admission rate Lambda for round t with dynamic range"""
        # Compute dynamic lambda range
        # Range converges to optimal_lambda_sum over time
        # At t=1: range is wide [1, 2*optimal_lambda_sum]
        # At t=inf: range is [optimal_lambda_sum, optimal_lambda_sum]
        t = max(round_num, 1)
        rho_t = self.rho ** t

        # Convergence factor: 1 - rho^t (goes from ~0 to ~1)
        convergence = 1.0 - rho_t

        # Compute dynamic lambda range
        # Lower bound: 40 * (1 - rho^(0.01*t))
        # Upper bound: 40 / (1 - rho^(0.01*t))
        t = max(round_num, 1)
        rho_t = self.rho ** (0.01 * t)  # rho^(0.01*t)

        lambda_min = 40.0 * (1.0 - rho_t)
        lambda_max_raw = 40.0 / (1.0 - rho_t + 1e-10)  # avoid division by zero

        # Cap upper bound at 100
        lambda_max = min(lambda_max_raw, 100.0)

        # Ensure valid range
        lambda_min = max(lambda_min, 1.0)
        lambda_max = max(lambda_max, lambda_min + 10.0)

        # Get current K (dynamic growth)
        current_K = self.get_current_K(round_num)

        # Update K for all memories
        self.update_memories_K(round_num)

        # Debug: print K value every 10 rounds
        if round_num % 10 == 0:
            print(f"[DPP Debug] Round {round_num}: K = {current_K}")

        Lambda_opt = self.find_optimal_lambda(round_cost, lambda_min, lambda_max, current_K)

        # Distribute Lambda to clients proportionally to buffer sizes
        lambda_m = Lambda_opt * self.buffer_sizes / self.sum_B_m
        lambda_m = np.maximum(1, np.round(lambda_m)).astype(int)

        Lambda_actual = sum(lambda_m)

        # Handle K growth: use prev_K for dropping to avoid using stale high-lambda history
        # when K has just increased. This prevents the algorithm from thinking it needs to
        # drop more samples than it actually should.
        effective_K = min(current_K, self.prev_K)
        Lambda_dropping = 0
        if len(self.lambda_history) >= effective_K:
            Lambda_dropping = self.lambda_history[-effective_K]

        # Update state
        self.n_t = self.n_t - Lambda_dropping + Lambda_actual
        self.N_t = self.N_t + Lambda_actual

        # Update prev_K for next round
        self.prev_K = current_K

        # Update cost-debt queue
        C_t = round_cost * Lambda_actual
        self.Z = max(0, self.Z + C_t - self.cost_budget)

        self.lambda_history.append(Lambda_actual)

        return Lambda_actual, lambda_m.tolist(), self.Z


# ==================== Optimal Policy 计算 (与 MNIST 一致) ====================

def compute_optimal_kstep_params(num_clients, cost_range, total_cost_budget, buffer_sizes):
    """
    Compute optimal K and lambda_m using closed-form solution from Paper Section 4.3.
    与 MNIST 版本完全一致。
    """
    c_min, c_max = cost_range
    c_bar = (c_min + c_max) / 2.0  # Expected cost for uniform distribution

    if len(buffer_sizes) != num_clients:
        raise ValueError(f"buffer_sizes length ({len(buffer_sizes)}) must match num_clients ({num_clients})")

    sum_B_m = sum(buffer_sizes)

    # Closed-form optimal K (from paper equation)
    K_candidate = (c_bar * sum_B_m) / total_cost_budget
    K_ceil = int(np.ceil(K_candidate))
    K_floor = int(np.floor(K_candidate))

    # Choose K that gives larger Lambda_bar
    lambda_bar_ceil = min(total_cost_budget / c_bar, sum_B_m / K_ceil)
    lambda_bar_floor = min(total_cost_budget / c_bar, sum_B_m / max(K_floor, 1))

    if lambda_bar_ceil >= lambda_bar_floor:
        best_K = K_ceil
        best_lambda_bar = lambda_bar_ceil
    else:
        best_K = max(K_floor, 1)
        best_lambda_bar = lambda_bar_floor

    # Determine active constraint
    cost_constraint = total_cost_budget / c_bar
    buffer_constraint = sum_B_m / best_K

    if cost_constraint < buffer_constraint:
        best_active_constraint = "cost"
    else:
        best_active_constraint = "buffer"

    # Compute per-client lambda_m (FLOAT version for fractional admission)
    if best_active_constraint == "buffer":
        # Buffer constraint is active: K * lambda_m <= B_m
        lambda_m_float = [B_m / best_K for B_m in buffer_sizes]
    else:
        # Cost constraint is active: distribute proportionally to buffer sizes
        lambda_m_float = [best_lambda_bar * B_m / sum_B_m for B_m in buffer_sizes]

    # Ensure all lambda_m are at least 0.1 (minimum fractional rate)
    lambda_m_float = [max(0.1, lam) for lam in lambda_m_float]

    # Also compute integer version for backward compatibility
    lambda_m_int = [int(np.floor(lam)) for lam in lambda_m_float]
    lambda_m_int = [max(1, lam) for lam in lambda_m_int]

    return {
        'K': best_K,
        'lambda_m': lambda_m_int,  # Integer version
        'lambda_m_float': lambda_m_float,  # Float version for fractional admission
        'lambda_bar': best_lambda_bar,
        'c_bar': c_bar,
        'buffer_constraint': buffer_constraint,
        'cost_constraint': cost_constraint,
        'active_constraint': best_active_constraint,
        'buffer_sizes': buffer_sizes,
        'sum_B_m': sum_B_m,
        'total_cost_budget': total_cost_budget,
        'K_candidate': K_candidate
    }


# ==================== Policy Setup (与 MNIST 一致) ====================

def setup_policy(policy_type, num_clients, user_indices):
    """设置选定的 policy"""
    policy_type = policy_type.lower()

    if policy_type == 'optimal':
        return setup_optimal_policy(num_clients, user_indices)
    elif policy_type == 'dpp':
        return setup_dpp_policy(num_clients, user_indices)
    elif policy_type == 'oracle':
        return setup_oracle_policy(num_clients, user_indices)
    elif policy_type == 'hybrid':
        return setup_hybrid_policy(num_clients, user_indices)
    else:
        raise ValueError(f"Unknown policy: {policy_type}")


def setup_optimal_policy(num_clients, user_indices):
    """K=10 Optimal Policy (与 MNIST 一致)"""
    cost_range = (1, 10)
    total_cost_budget = COST_BUDGET
    buffer_sizes = BUFFER_SIZES

    optimal_params = compute_optimal_kstep_params(
        num_clients=num_clients,
        cost_range=cost_range,
        total_cost_budget=total_cost_budget,
        buffer_sizes=buffer_sizes
    )

    # Force K=10
    K = 10
    lambda_m = optimal_params['lambda_m_float']  # Use fractional lambda

    print(f"\n{'='*70}")
    print("Policy: K-Step OPTIMAL K=10 (Paper Section 4.3)")
    print(f"{'='*70}")
    print(f"  K (retention horizon): {K} (fixed K=10)")
    print(f"  Per-client lambda_m (fractional): {[f'{x:.2f}' for x in lambda_m]}")
    print(f"  Buffer sizes: {buffer_sizes}")
    print(f"  Cost budget: {total_cost_budget}")
    print(f"  Active constraint: {optimal_params['active_constraint']}")
    print(f"{'='*70}\n")

    memories = {}
    samplers = {}
    dithers = {}

    for client_id in range(num_clients):
        memories[client_id] = KStepMemory(K=K)
        samplers[client_id] = OracleSampler(user_indices[client_id], seed=42 + client_id)
        dithers[client_id] = RateDither(lam=lambda_m[client_id])  # Fractional lambda with counter

    return {
        'memories': memories,
        'samplers': samplers,
        'dithers': dithers,
        'K': K,
        'lambda_m': lambda_m,
        'dpp_policy': None,
        'is_static': [False] * num_clients,
        'static_clients': []
    }


def setup_dpp_policy(num_clients, user_indices):
    """K=4 DPP Policy (与 MNIST 一致，Pdim=100)"""
    try:
        K = 4
        buffer_sizes = BUFFER_SIZES
        cost_budget = COST_BUDGET

        # DPP parameters (CIFAR 使用 Pdim=1024)
        V = 10000.0
        D = 1000.0
        sigma = 10.0
        eta_tilde = 0.005  # 学习率相关
        C1 = 1000.0
        Pdim = 1024  # CIFAR 使用 1024

        # DPP K growth parameters
        K_initial = 6
        K_target = 6
        K_growth_interval = 9999  # K grows every 9999 rounds

        print(f"\n{'='*70}")
        print("Policy: K-Step DPP (Drift-Plus-Penalty)")
        print(f"{'='*70}")
        print(f"  K (initial): {K_initial}")
        print(f"  K (target): {K_target}")
        print(f"  K growth: +1 every {K_growth_interval} rounds")
        print(f"  Buffer sizes: {buffer_sizes}")
        print(f"  Cost budget: {cost_budget}")
        print(f"  DPP parameters: V={V}, D={D}, sigma={sigma}, Pdim={Pdim}, K_growth_interval={K_growth_interval}")
        print(f"{'='*70}\n")

        # Compute optimal lambda sum for dynamic range
        sum_B_m = sum(buffer_sizes)
        c_bar = 25.0  # (1+49)/2
        K_optimal = int(np.ceil((c_bar * sum_B_m) / cost_budget))
        optimal_lambda_sum = sum_B_m / K_optimal

        dpp_policy = DPPLambdaPolicy(
            cost_budget=cost_budget,
            buffer_sizes=buffer_sizes,
            K_initial=K_initial,
            K_target=K_target,
            K_growth_interval=K_growth_interval,
            V=V,
            D=D,
            sigma=sigma,
            eta_tilde=eta_tilde,
            C1=C1,
            C2=1.0,
            Pdim=Pdim,
            optimal_lambda_sum=optimal_lambda_sum,
            rho=0.999
        )

        print(f"  Dynamic lambda range: converging to {optimal_lambda_sum:.1f}")
        print(f"  rho={0.999}")
        print(f"{'='*70}\n")

        memories = {}
        samplers = {}
        dithers = {}

        for client_id in range(num_clients):
            memories[client_id] = KStepMemory(K=K_initial)  # Use K_initial
            samplers[client_id] = OracleSampler(user_indices[client_id], seed=42 + client_id)
            dithers[client_id] = DynamicRateDither()

        # Store memories reference in dpp_policy for dynamic K updates
        dpp_policy.set_memories(memories)

        return {
            'memories': memories,
            'samplers': samplers,
            'dithers': dithers,
            'K': K,
            'lambda_m': None,
            'dpp_policy': dpp_policy,
            'is_static': [False] * num_clients,
            'static_clients': []
        }
    except Exception as e:
        print(f"ERROR in setup_dpp_policy: {e}")
        import traceback
        traceback.print_exc()
        return None


def setup_oracle_policy(num_clients, user_indices):
    """K=1 Oracle Policy (与 MNIST 一致)"""
    K = 1
    # Oracle: lambda_m = buffer_sizes (since K=1, steady-state buffer = K * lambda_m = lambda_m)
    lambda_m = BUFFER_SIZES
    cost_budget = COST_BUDGET

    print(f"\n{'='*70}")
    print("Policy: K=1 ORACLE")
    print(f"{'='*70}")
    print(f"  K (retention horizon): {K}")
    print(f"  Per-client lambda_m: {lambda_m}")
    print(f"  Steady-state buffer: {[K * lam for lam in lambda_m]}")
    print(f"  Cost: Uniform[1, 10] per round")
    print(f"{'='*70}\n")

    memories = {}
    samplers = {}
    dithers = {}

    for client_id in range(num_clients):
        memories[client_id] = KStepMemory(K=K)
        samplers[client_id] = OracleSampler(user_indices[client_id], seed=42 + client_id)
        dithers[client_id] = RateDither(lam=lambda_m[client_id])

    return {
        'memories': memories,
        'samplers': samplers,
        'dithers': dithers,
        'K': K,
        'lambda_m': lambda_m,
        'dpp_policy': None,
        'is_static': [False] * num_clients,
        'static_clients': []
    }


def setup_hybrid_policy(num_clients, user_indices):
    """Hybrid: 5 Dynamic (Optimal K=10) + 5 Static (与 MNIST 一致)"""
    if num_clients != 10:
        raise ValueError(f"Hybrid policy requires 10 clients, got {num_clients}")

    dynamic_clients = list(range(5))   # 0-4
    static_clients = list(range(5, 10))  # 5-9

    # Dynamic clients config (Optimal)
    cost_range = (1, 10)
    total_cost_budget = COST_BUDGET
    dynamic_buffer_sizes = BUFFER_SIZES[:5]

    optimal_params = compute_optimal_kstep_params(
        num_clients=5,  # Only 5 dynamic clients
        cost_range=cost_range,
        total_cost_budget=total_cost_budget,
        buffer_sizes=dynamic_buffer_sizes
    )

    # Force K=10 for Hybrid
    K = 10
    lambda_m = optimal_params['lambda_m_float']  # Use fractional lambda

    # Static clients config
    static_buffer_sizes = BUFFER_SIZES[5:]

    print(f"\n{'='*70}")
    print("Policy: HYBRID (5 Dynamic Optimal K=10 + 5 Static)")
    print(f"{'='*70}")
    print(f"Dynamic Clients (0-4):")
    print(f"  K (retention horizon): {K} (fixed K=10)")
    print(f"  Per-client lambda_m (fractional): {[f'{x:.2f}' for x in lambda_m]}")
    print(f"  Buffer sizes: {dynamic_buffer_sizes}")
    print(f"  Cost budget: {total_cost_budget}")
    print(f"  Active constraint: {optimal_params['active_constraint']}")
    print(f"Static Clients (5-9):")
    print(f"  Fixed buffer sizes: {static_buffer_sizes}")
    print(f"  Cost budget: 0 (pre-allocated)")
    print(f"{'='*70}\n")

    memories = {}
    samplers = {}
    dithers = {}
    is_static = []

    # Setup dynamic clients (0-4)
    for i, client_id in enumerate(dynamic_clients):
        memories[client_id] = KStepMemory(K=K)
        samplers[client_id] = OracleSampler(user_indices[client_id], seed=42 + client_id)
        dithers[client_id] = RateDither(lam=lambda_m[i])  # Fractional lambda with counter
        is_static.append(False)

    # Setup static clients (5-9) - pre-allocate fixed samples
    for i, client_id in enumerate(static_clients):
        buffer_size = static_buffer_sizes[i]
        # Pre-allocate first 'buffer_size' samples from this client's data
        static_indices = list(user_indices[client_id])[:buffer_size]
        memories[client_id] = StaticMemory(static_indices)
        samplers[client_id] = None  # Static clients don't need sampler
        dithers[client_id] = None   # Static clients don't need dither
        is_static.append(True)

    return {
        'memories': memories,
        'samplers': samplers,
        'dithers': dithers,
        'K': K,
        'lambda_m': lambda_m,
        'dpp_policy': None,
        'is_static': is_static,
        'static_clients': static_clients,
        'dynamic_buffer_sizes': dynamic_buffer_sizes,
        'static_buffer_sizes': static_buffer_sizes
    }


# ==================== 模型定义 (ResNet-9) ====================

class ResNet9(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, 3, padding=1)
        self.bn1 = nn.GroupNorm(32, 64)
        self.conv2 = nn.Conv2d(64, 128, 3, padding=1)
        self.bn2 = nn.GroupNorm(32, 128)
        self.pool1 = nn.MaxPool2d(2, 2)

        self.res1 = nn.Sequential(
            nn.Conv2d(128, 128, 3, padding=1),
            nn.GroupNorm(32, 128),
            nn.Mish(),
            nn.Conv2d(128, 128, 3, padding=1),
            nn.GroupNorm(32, 128),
        )

        self.conv3 = nn.Conv2d(128, 256, 3, padding=1)
        self.bn3 = nn.GroupNorm(32, 256)
        self.pool2 = nn.MaxPool2d(2, 2)

        self.conv4 = nn.Conv2d(256, 512, 3, padding=1)
        self.bn4 = nn.GroupNorm(32, 512)
        self.pool3 = nn.MaxPool2d(2, 2)

        self.res2 = nn.Sequential(
            nn.Conv2d(512, 512, 3, padding=1),
            nn.GroupNorm(32, 512),
            nn.Mish(),
            nn.Conv2d(512, 512, 3, padding=1),
            nn.GroupNorm(32, 512),
        )

        self.pool4 = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512, 10)

    def forward(self, x):
        x = torch.nn.functional.mish(self.bn1(self.conv1(x)))
        x = torch.nn.functional.mish(self.bn2(self.conv2(x)))
        x = self.pool1(x)
        x = self.res1(x) + x
        x = torch.nn.functional.mish(x)
        x = torch.nn.functional.mish(self.bn3(self.conv3(x)))
        x = self.pool2(x)
        x = torch.nn.functional.mish(self.bn4(self.conv4(x)))
        x = self.pool3(x)
        x = self.res2(x) + x
        x = torch.nn.functional.mish(x)
        x = self.pool4(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)


# ==================== 训练和评估 ====================

def local_train_fullbatch(model, train_dataset, memory_indices, device, epochs=10, lr=1e-4):
    """在 memory buffer 上进行 full-batch 训练，使用 SGD 优化器"""
    if len(memory_indices) == 0:
        return None, 0.0

    model.train()
    loader = DataLoader(Subset(train_dataset, memory_indices),
                       batch_size=max(1, len(memory_indices)), shuffle=True)
    # 使用 SGD with momentum
    optimizer = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    criterion = nn.CrossEntropyLoss()

    epoch_losses = []
    for _ in range(epochs):
        batch_losses = []
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            batch_losses.append(loss.item())
        epoch_losses.append(sum(batch_losses) / max(1, len(batch_losses)))

    return model.state_dict(), sum(epoch_losses) / max(1, len(epoch_losses))


def evaluate(model, test_dataset, device):
    """在全局测试集上评估"""
    model.eval()
    loader = DataLoader(test_dataset, batch_size=128, shuffle=False)
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            pred = output.argmax(dim=1)
            correct += pred.eq(target).sum().item()
            total += target.size(0)
    return 100. * correct / total


def weighted_average_weights(weights_list, sample_counts):
    """按样本数加权聚合"""
    total = sum(sample_counts)
    if total == 0 or len(weights_list) == 0:
        return None

    if len(weights_list) == 1:
        return weights_list[0]

    avg_weights = copy.deepcopy(weights_list[0])
    weights = [n / total for n in sample_counts]

    for k in avg_weights.keys():
        avg_weights[k] = weights_list[0][k] * weights[0]
        for i in range(1, len(weights_list)):
            avg_weights[k] += weights_list[i][k] * weights[i]
    return avg_weights


# ==================== 主函数 ====================

def main():
    parser = argparse.ArgumentParser(description='CIFAR-10 Streaming Federated Learning')
    parser.add_argument('--policy', type=str, default='optimal',
                       choices=['optimal', 'dpp', 'oracle', 'hybrid'],
                       help='Sampling policy to use')
    parser.add_argument('--epochs', type=int, default=100,
                       help='Number of global rounds')
    parser.add_argument('--local_epochs', type=int, default=30,
                       help='Number of local epochs')
    parser.add_argument('--lr', type=float, default=0.1,
                       help='Learning rate')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--run_num', type=int, default=1,
                       help='Run number for multiple experiments')
    args = parser.parse_args()

    # 设置随机种子
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    print("="*70)
    print(f"CIFAR-10 Streaming Federated Learning - {args.policy.upper()} Policy")
    print(f"Data directory: {DATA_DIR}")
    print(f"Save directory: {SAVE_DIR}")
    print("="*70)

    # 设备 - 优先 CUDA
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"\n✓ Using GPU: {torch.cuda.get_device_name(0)}")
    elif torch.backends.mps.is_available():
        device = torch.device("mps")
        print(f"\n✓ Using M2 Pro GPU (MPS)")
    else:
        device = torch.device("cpu")
        print(f"\n✗ Using CPU")

    # 加载数据
    print("\nLoading CIFAR-10...")
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    train_dataset = torchvision.datasets.CIFAR10(root=DATA_DIR, train=True,
                                                  download=True, transform=transform)
    test_dataset = torchvision.datasets.CIFAR10(root=DATA_DIR, train=False,
                                                 download=True, transform=transform)
    print(f"Train: {len(train_dataset)}, Test: {len(test_dataset)}")

    # Non-i.i.d. 数据分配 - 相邻重叠类别对: {0,1}{1,2}{2,3}{3,4}...{8,9}
    print("\nPartitioning data (non-i.i.d., 2 classes per user, overlapping pairs)...")
    num_users = 10
    labels = np.array(train_dataset.targets)
    user_indices = {}

    # 相邻重叠类别对: {0,1}, {1,2}, {2,3}, {3,4}, {4,5}, {5,6}, {6,7}, {7,8}, {8,9}, {9,0}
    # 这样每个类别出现在两个相邻的 client 中
    fixed_class_pairs = [[i, (i+1) % 10] for i in range(10)]

    for i in range(num_users):
        classes = fixed_class_pairs[i]  # 使用固定类别对
        indices = []
        for c in classes:
            idx = np.where(labels == c)[0]
            selected = np.random.choice(idx, min(500, len(idx)), replace=False)
            indices.extend(selected)
        user_indices[i] = indices
        print(f"  Client {i}: classes {classes}, {len(indices)} samples")

    print(f"Users: {num_users}, ~{len(user_indices[0])} samples/user")

    # 设置 Policy
    print(f"\nSetting up policy: {args.policy}")
    policy_components = setup_policy(args.policy, num_users, user_indices)

    if policy_components is None:
        print(f"ERROR: Failed to setup policy '{args.policy}'")
        print(f"Available policies: optimal, dpp, oracle, hybrid")
        return

    memories = policy_components['memories']
    samplers = policy_components['samplers']
    dithers = policy_components['dithers']
    K = policy_components['K']
    dpp_policy = policy_components['dpp_policy']
    is_static = policy_components['is_static']
    static_clients = policy_components.get('static_clients', [])

    # 全局模型
    global_model = ResNet9().to(device)
    print(f"Parameters: {sum(p.numel() for p in global_model.parameters()):,}")

    # 训练循环
    print("\n" + "="*70)
    print(f"Starting Training ({args.epochs} rounds)")
    print("="*70)

    start = time.time()
    history = {
        'round': [],
        'test_accuracy': [],
        'avg_buffer_size': [],
        'total_cost': [],
        'time': []
    }

    cost_rng = np.random.default_rng(args.seed)

    for round_idx in range(args.epochs):
        current_round = round_idx + 1

        local_weights = []
        local_losses = []
        buffer_sizes = []
        round_total_cost = 0

        # 生成随机成本
        round_cost = cost_rng.integers(1, 50)

        # DPP: 获取当前轮的 lambda
        if dpp_policy is not None:
            _, lambda_m_round, Z = dpp_policy.get_lambda_for_round(current_round, round_cost)
            for idx in range(num_users):
                if dithers[idx] is not None:
                    dithers[idx].set_lambda(lambda_m_round[idx])

        # 每个客户端处理
        for user_id in range(num_users):
            # 淘汰旧样本
            memories[user_id].drop_first(current_round)

            # 接纳新样本（仅 non-static clients）
            if not is_static[user_id]:
                n_admit = dithers[user_id].next_int()
                if n_admit > 0:
                    new_indices = samplers[user_id].sample_fresh(n_admit)
                    memories[user_id].admit(new_indices, current_round)
                round_total_cost += n_admit * round_cost

            # 获取 memory 中的样本
            memory_indices = memories[user_id].indices()
            buffer_sizes.append(len(memories[user_id]))

            # 本地训练
            local_model = copy.deepcopy(global_model)
            weights, loss = local_train_fullbatch(
                local_model, train_dataset, memory_indices, device,
                epochs=args.local_epochs, lr=args.lr
            )

            if weights is not None:
                local_weights.append(weights)
                local_losses.append(loss)

        # 服务器聚合
        if len(local_weights) > 0:
            global_weights = weighted_average_weights(local_weights, buffer_sizes)
            if global_weights is not None:
                global_model.load_state_dict(global_weights)

        # 评估
        avg_buffer = sum(buffer_sizes) / len(buffer_sizes)
        loss_avg = sum(local_losses) / len(local_losses) if len(local_losses) > 0 else 0

        # 计算训练准确率
        train_correct = 0
        train_total = 0
        for user_id in range(num_users):
            memory_indices = memories[user_id].indices()
            if len(memory_indices) > 0:
                loader = DataLoader(Subset(train_dataset, memory_indices),
                                   batch_size=128, shuffle=False)
                with torch.no_grad():
                    for data, target in loader:
                        data, target = data.to(device), target.to(device)
                        output = global_model(data)
                        pred = output.argmax(dim=1)
                        train_correct += pred.eq(target).sum().item()
                        train_total += target.size(0)
        train_acc = 100. * train_correct / max(1, train_total)

        elapsed = time.time() - start

        # 每轮都打印
        # 每轮都计算 test acc 并输出
        test_acc = evaluate(global_model, test_dataset, device)
        print(f"Round {current_round:3d}/{args.epochs} | "
              f"Train Acc: {train_acc:.2f}% | Test Acc: {test_acc:5.2f}% | "
              f"Train Loss: {loss_avg:.4f} | Buffer: {avg_buffer:5.1f} | "
              f"Cost: {round_total_cost:4.0f} | Time: {elapsed:.1f}s")

        history['round'].append(int(current_round))
        history['test_accuracy'].append(float(test_acc))
        history['avg_buffer_size'].append(float(avg_buffer))
        history['total_cost'].append(int(round_total_cost))
        history['time'].append(float(elapsed))

    # 结束
    total = time.time() - start
    final_test_acc = evaluate(global_model, test_dataset, device)

    print("="*70)
    print(f"\nCompleted! ({args.policy.upper()} Policy)")
    print(f"Final Test Accuracy: {final_test_acc:.2f}%")
    print(f"Total time: {total:.1f}s (~{total/60:.1f} min)")

    # 保存结果
    output_dir = os.path.join(SAVE_DIR, 'experiment_outputs')
    os.makedirs(output_dir, exist_ok=True)

    model_path = os.path.join(output_dir, f'cifar10_{args.policy}_run{args.run_num}.pth')
    torch.save(global_model.state_dict(), model_path)

    # 保存 history (转换 numpy 类型)
    history_path = os.path.join(output_dir, f'history_{args.policy}_run{args.run_num}.json')
    with open(history_path, 'w') as f:
        json.dump(history, f, indent=2)

    config = {
        'policy': args.policy,
        'K': int(K),
        'num_users': num_users,
        'local_epochs': args.local_epochs,
        'lr': args.lr,
        'num_rounds': args.epochs,
        'final_test_acc': float(final_test_acc),
        'total_time': float(total)
    }
    config_path = os.path.join(output_dir, f'config_{args.policy}_run{args.run_num}.json')
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    print(f"\nResults saved to: {output_dir}")


if __name__ == '__main__':
    main()

